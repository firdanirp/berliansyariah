<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Login_model extends CI_Model{
        function __construct(){
        	parent::__construct();
	    }
		function validate($user, $pass){
            
            $sql = "SELECT * FROM admin WHERE username='".$user."' && password='".$pass."'";
			
			$query = $this->db->query($sql);
			
			if($query->num_rows == 1)
			{
					return true;
			}
		}
	
}