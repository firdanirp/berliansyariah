<?php

class User_model extends CI_Model {
	function get_records($tabel)
	{	
		$query = $this->db->get($tabel);
		
		return $query->result();
	}
	
	function get_records_where($tabel, $id)
	{	
		$query = $this->db->get_where($tabel,"id = '".$id."'");
		return $query->result();
	}
	
	function add_record($tabel, $data)
	{
		$this->db->insert($tabel,$data);
		return;
	}
	

	function login($username,$pass){
		$sql = $this->db->query("SELECT * FROM user WHERE username = '".$username."' AND password = '".$pass."'");
		return $sql->result();
		
	}
	
	function update_record($data, $id,$table)
	{
		$this->db->where('id', $id);
		$this->db->update($table, $data);
		return;
	}
	
	function delete_row($where1,$where,  $tabel)
	{
		$this->db->where($where1, $where);
		$this->db->delete($tabel);
		return;
	}
	function getLastRow($kec){
		$sql = $this->db->query("SELECT * FROM user WHERE id_kec = '".$kec."' ORDER BY idUser DESC ");	
		return $sql->result();
		
	}
	public function tampil_user()
    {
        return $this->db->get('user');
    }
	
}
?>