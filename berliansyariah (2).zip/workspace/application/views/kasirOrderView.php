<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>Order</title>
</head>
<body class="eternity-form" > 
	<section class="" id="formOrder">
		<div class="container">

			<div class="form-group">
				<label class="col-md-4 control-label" for="textinput">Nama Pemesan</label> 
				<div class="col-md-4">
					<input id="textinput" name="textinput" class="form-control input-md" type="text">  
				</div>
			</div>

			<div class="form-group">
                 <label for="col-md-4 control-label ">Tipe Kamar</label>
                 <div class="col-md-4">
                  <select class="form-control" name="tipeKamar" >
                      <option value="Twin Bed">Twin Bed</option>
                      <option value="Deluxe">Deluxe</option>
                      <option value="Single Superior">Single Superior</option>
                  </select>
                 </div>
            </div>

            <div class="form-group">
            	  <label for="col-md-4 control-label">Check In</label>
            	  <div class='input-group date' id='datetimepicker1'>
                    <input type='text' class="form-control" />
                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
            </div>


		</div>
	</section>

	<script src="<?=base_url()?>assets/Login/js/jquery-1.9.1.js"></script>
	<script src="<?=base_url()?>assets/bs3.3.7/js/bootstrap.js"></script>
	<script src="<?=base_url()?>assets/Login/js/respond.src.js"></script>
	<script src="<?=base_url()?>assets/Login/js/jquery.icheck.js"></script>
	<script src="<?=base_url()?>assets/Login/js/placeholders.min.js"></script>
	<script src="<?=base_url()?>assets/Login/js/waypoints.min.js"></script>
	<script src="<?=base_url()?>assets/Login/js/jquery.panelSnap.js"></script>

	<script type="text/javascript">

		$(function () {
                $('#datetimepicker1').datetimepicker();
            });

		$(function () {
			$("input").iCheck({
				checkboxClass: 'icheckbox_square-blue',
                increaseArea: '20%' // optional
            });
			$(".dark input").iCheck({
				checkboxClass: 'icheckbox_polaris',
                increaseArea: '20%' // optional
            });
			$(".form-control").focus(function () {
				$(this).closest(".textbox-wrap").addClass("focused");
			}).blur(function () {
				$(this).closest(".textbox-wrap").removeClass("focused");
			});

            //On Scroll Animations


            if ($(window).width() >= 968 && !Modernizr.touch && Modernizr.cssanimations) {

            	$("body").addClass("scroll-animations-activated");
            	$('[data-animation-delay]').each(function () {
            		var animationDelay = $(this).data("animation-delay");
            		$(this).css({
            			"-webkit-animation-delay": animationDelay,
            			"-moz-animation-delay": animationDelay,
            			"-o-animation-delay": animationDelay,
            			"-ms-animation-delay": animationDelay,
            			"animation-delay": animationDelay
            		});

            	});
            	$('[data-animation]').waypoint(function (direction) {
            		if (direction == "down") {
            			$(this).addClass("animated " + $(this).data("animation"));

            		}
            	}, {
            		offset: '90%'
            	}).waypoint(function (direction) {
            		if (direction == "up") {
            			$(this).removeClass("animated " + $(this).data("animation"));

            		}
            	}, {
            		offset: $(window).height() + 1
            	});
            }

            //End On Scroll Animations


            $(".main-nav a[href]").click(function () {
            	var scrollElm = $(this).attr("href");

            	$("html,body").animate({ scrollTop: $(scrollElm).offset().top }, 500);

            	$(".main-nav a[href]").removeClass("active");
            	$(this).addClass("active");
            });




            if ($(window).width() > 1000 && !Modernizr.touch) {
            	var options = {
            		$menu: ".main-nav",
            		menuSelector: 'a',
            		panelSelector: 'section',
            		namespace: '.panelSnap',
            		onSnapStart: function () { },
            		onSnapFinish: function ($target) {
            			$target.find('input:first').focus();
            		},
            		directionThreshold: 50,
            		slideSpeed: 200
            	};
            	$('body').panelSnap(options);

            }

            $(".colorBg a[href]").click(function () {
            	var scrollElm = $(this).attr("href");

            	$("html,body").animate({ scrollTop: $(scrollElm).offset().top }, 500);

            	return false;
            });




        });
    </script>

</body>
</html>
