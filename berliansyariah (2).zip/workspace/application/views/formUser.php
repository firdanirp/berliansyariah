<div class="right-content-inner">
            <section class="page-header alternative-header">
  <ol class="breadcrumb">
    <li>Admin Berlian Syariah</li>
    <li>User</li>
  </ol>
  <div class="page-header_title">
    <h1>
      <span data-i18n="dashboard1.dashboard">User</span>
      <span class="page-header_subtitle" data-i18n="dashboard1.welcomeMsg" data-i18n-options="{&quot;username&quot;: &quot;John Doe&quot;}">Halaman User</span>
    </h1>
  </div>
</section>
<script>
      $(function () {
        $("#tableUser").DataTable({
          "language": {
            "url": "<?php echo base_url(); ?>assets/plugins/datatables/Indonesian.json",
            "sEmptyTable": "Tidak ada data di database"
        }
        });
      });
      </script>
            <section class="page-content">
            <div class="panel panel-default">
            <div class="panel-body">
             <!-- CONTENT --> 
             
             <div class="box-body table-responsive no-padding">
               <div class="input-group" style="width: 150px;">
                      <input type="text" name="table_search" class="form-control input-sm pull-right" placeholder="Search">
                      <div class="input-group-btn">
                        <button class="btn btn-sm btn-default"><i class="fa fa-search"></i></button>
                      </div>
                    </div>

                  <table id="tableUser" class="table table-bordered table-hover dataTable">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>Jabatan</th>
                        <th>Username</th>
                        <th>Password</th>
                        <th>Aksi</th>
                    </thead>
                    <tbody>
                      	<?php
                        $no = 1;
                        foreach ($dataUser as $lihat):
                        ?>
                    	<tr>
                        <td><?php echo $no++ ?></td>
                    	  <td><?php echo ($lihat->nama)?></td>
                    	<td><?php echo ($lihat->alamat) ?></td>
                      <td><?php echo ucwords($lihat->jabatan) ?></td>
                      <td><?php echo ($lihat->username) ?></td>
                      <td><?php echo ($lihat->password) ?></td>
                        <td align="center">
                          <div class="btn-group" role="group">
                            <a href="" class="btn btn-sm btn-primary btn-flat" title="Detail"><i class="glyphicon glyphicon-eye-open"></i></a>
                            <a href="" class="btn btn-sm btn-primary btn-flat" title="Edit"><i class="fa fa-edit"></i></a>
                            <a href="" onclick="javascript: return confirm('Anda yakin akan menghapus data ini ?')" class="btn btn-sm btn-danger btn-flat" title="Hapus"><i class="glyphicon glyphicon-remove"></i></a>
                          </div>
                        </td>
                    	</tr>
                    	<?php endforeach; ?>
                    </tbody>
                  </table>
                                </div>
             <form class="form" action="<?=base_url()?>User/create" enctype="multipart/form-data" method="post">
                <div class="form-group">
                  <input type="text" name="username" class="form-control" id="regular3">
                  <label for="regular3">Username</label>
                </div>
                <div class="form-group">
                  <input type="password" class="form-control" id="password1" name="pass">
                  <label for="password1">Password</label>
                </div>
                <div class="form-group">
                  <input type="text" name="nama" class="form-control" id="placeholder1" >
                  <label for="placeholder1">Nama</label>
                </div>
                <div class="form-group">
                  <input type="text" name="alamat" class="form-control" id="placeholder1">
                  <label for="placeholder1">Alamat</label>
                </div>
                <div class="form-group">
                  <input type="date" name="tgl_lahir" class="form-control">
                  <label for="placeholder1">Tanggal Lahir</label>
                </div>
                <div class="form-group">
                  <select name="jk" class="form-control" id="select1">
                  	<option value="">&nbsp;</option>
                    <option value="L">Laki-Laki</option>
                    <option value="P">Perempuan</option>
                  </select>
                  <label for="placeholder1">Jenis Kelamin</label>
                </div>
                <div class="form-group">
                  <select name="jabatan" class="form-control" id="select1">
                  	<option value="">&nbsp;</option>
                  	<option value="0">Manager</option>
                    <option value="1">Kasir</option>
                  </select>
                  <label for="placeholder1">Jabatan</label>
                </div>
                
                <div class="form-group">
                  <input type="text" name="noTelp" class="form-control">
                  <label for="placeholder1">Nomor Telepon</label>
                </div>
                
                <div class="form-group">
                  <input type="file" name="file_name" class="form-control">
                  <label for="placeholder1">Foto</label>
                </div>
                
                <input type="submit" class="btn btn-success" value="Submit"	 />
                <input type="reset" class="btn btn-danger" value="Cancel"	 />
                
              </form>


              </div>
            </section>
          </div>

