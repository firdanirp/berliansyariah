<div class="right-content-inner">
            <section class="page-header alternative-header">
  <ol class="breadcrumb">
    <li>Kasir Berlian Syariah</li>
    <li>Kamar</li>
  </ol>
  <div class="page-header_title">
    <h1>
      <span data-i18n="dashboard1.dashboard">Kamar</span>
      <span class="page-header_subtitle" data-i18n="dashboard1.welcomeMsg" data-i18n-options="{&quot;username&quot;: &quot;John Doe&quot;}">Welcome back John Doe</span>
    </h1>
  </div>
</section>
            <section class="page-content">
            <div class="panel panel-default">
            <div class="panel-body">
             <!-- CONTENT --> 
             <form class="form">
                <div class="form-group">
                  <input type="text" class="form-control" id="regular3">
                  <label for="regular3">Regular input</label>
                </div>
                <div class="form-group">
                  <input type="password" class="form-control" id="password1">
                  <label for="password1">Password</label>
                </div>
                <div class="form-group">
                  <input type="text" class="form-control" id="placeholder1" placeholder="Placeholder">
                  <label for="placeholder1">Placeholder</label>
                </div>
                <div class="form-group">
                  <input type="text" class="form-control" id="help1">
                  <label for="help1">Input with help text</label>
                  <p class="help-block">Help text</p>
                </div>
                <div class="form-group">
                  <input type="text" class="form-control" id="tooltip1" data-toggle="tooltip" data-placement="bottom" data-trigger="hover" data-original-title="Example input tooltip text here">
                  <label for="help1">Input with tooltip</label>
                </div>
                <div class="form-group has-success">
                  <input type="text" class="form-control" id="success1">
                  <label for="success1">Success</label>
                </div>
                <div class="form-group has-error">
                  <input type="text" class="form-control" id="error1">
                  <label for="error1">Error</label>
                </div>
              </form>

              </div>
              </div>
            </section>
          </div>

