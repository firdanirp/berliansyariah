<?php 
		$aaa=$this->session->userdata('idUser');
	    if($aaa=="")redirect(base_url().'Login');
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]--><head>
    <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
    <base href="">
    <title>Beranda Admin</title>


    <!-- Bootstrap Core CSS - Include with every page -->
    <link href="<?=base_url()?>assets/bs3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
    <!-- Bemat Admin CSS - Include with every page -->
    <link href="<?=base_url()?>assets/kasir/bemat-admin.css" rel="stylesheet" id="theme-switcher">
    <link href="<?=base_url()?>assets/malihu-custom-scrollbar-plugin-master/jquery.mCustomScrollbar.min.css" rel="stylesheet"/>
    <link href="<?=base_url()?>assets/fontawesome/css/font-awesome.css" rel="stylesheet"/>
    <link href="<?php echo base_url('assets/datatables/css/dataTables.bootstrap.css')?>" rel="stylesheet">

    <style>
      #page-wrapper #left-content #userbox{
       background: #009688 url("<?=base_url()?>assets/userbox-bg.png") left 40%;
      }
     .page-header.alternative-header {
    background: #009688 url("<?=base_url()?>assets/page-title-bg.png") no-repeat scroll 0% 0%;
    background-size: cover;
      }



      </style>
  </head>

    
   <!-- <div id="splash-screen" class="layout layout-align-center">
      <div class="logo-box logo-box-primary layout layout-column">
        <div class="logo">
          <b>BS</b>
        </div>
        <div class="logo-label headline-inverse">
          <p>BERLIAN SYARIAH</p>
        </div>
      </div>
    </div>
    -->
    
    <div id="page-wrapper"> 


      <aside id="left-content" data-toggle="open" data-default="open" data-size="">

        <header class="header-container navbar-dark bg-inverse">
          <div class="header-wrapper" >
            <div id="header-brand" style="background-color:#3b3f3f;">
              <div class="logo padding-left-2">
                <span class="logo-image">BS</span>
                <span class="logo-text">Berlian Syariah</span>
              </div>
            </div>
          </div>
        </header>

        <div id="sidebar-wrapper" class="mCustomScrollbar" data-mcs-theme="dark-light" style="overflow:hidden">
          <nav id="sidebar">
            <ul>
            <div id="userbox"> 
            <div id="useravatar">
              <div class="avatar-thumbnail">
                <img src="<?=base_url()?>/assets/avatar-square-blue.png" class="img-circle"/>
              </div>

            </div>
`

            <div id="userinfo">
              <div class="btn-group">
                <button type="button" class="btn btn-default-bright btn-flat dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">John Doe 
                </button>
              </div>
            </div>
          </div>
            <li class="nav-main-heading ">
                <span class="sidebar-mini-hide" data-i18n="nav.bac.bematAdmin">Menu Admin</span>
              </li>
            <li>
                <a href="<?=base_url()?>Kamar">
                  <span class="menu-item-ico"><i class="material-icons">apps</i></span>
                  <span class="menu-item-name" data-i18n="nav.dashboard">Kamar</span>
                  <div class="materialRipple-md-ripple-container"></div>
                </a>
              </li>
              <li>
                <a href="#">
                  <span class="menu-item-ico"><i class="material-icons">format_align_left</i></span>
                  <span class="menu-item-name" data-i18n="nav.forms.forms">Order</span>
                </a>
                  </li>             
              <li>
                <a href="#">
                  <span class="menu-item-ico"><i class="material-icons">insert_drive_file</i></span>
                  <span class="menu-item-name" data-i18n="nav.premadePages.pages">Pembayaran</span>
                </a>
              </li>
              <li>
                <a href="<?=base_url()?>User">
                  <span class="menu-item-ico"><i class="material-icons">insert_drive_file</i></span>
                  <span class="menu-item-name" data-i18n="nav.premadePages.pages">User</span>
                </a>
              </li>
          </nav><!-- END: nav#sidebar -->

      </aside>

      
      <section id="right-content">
        <header class="header-container">
          <div class="header-wrapper">
            <div id="header-toolbar" style="background-color:#3b3f3f;">
              <ul class="toolbar toolbar-left">
                <li>
                  <a id="sidebar-toggle" data-state="open" href="javascript:void(0)"><i class="material-icons md-light">menu</i></a>
                </li>
              </ul>

              <ul class="toolbar toolbar-right">
              <li>
                  <a href="javascript:void(0);" id="fullscreen-toggle" data-toggle="tooltip" data-placement="bottom" title="Toggle Fullscreen" data-i18n="[title]headerToolbar.fullscreenToggle"><i class="material-icons md-light">fullscreen</i></a>
                </li>
                <li id="user-profile" class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <div class="avatar">
                      <img src="<?=base_url()?>assets/avatar-square-blue.png" class="img-circle img-responsive" />
                    </div>
                    <div class="user">
                      <span class="username" style="color:silver;">John Doe</span>
                    </div>
                    <span class="expand-ico"><i class="material-icons md-light">expand_more</i></span>
                  </a>
                  <ul class="dropdown-menu dropdown-menu-right">
                    <li><a href="#"><i class="material-icons">person</i> <span data-i18n="userinfo.profile">Profil Anda</span></a></li>
                    <li class="divider-horizontal"></li>
                    <li><a href="#"><i class="material-icons">exit_to_app</i> <span data-i18n="userinfo.logout">Log Out</span></a></li>
                  </ul>
                </li><!-- /#user-profile -->
              </ul><!-- /.navbar-right -->          


            </div>
          </div><!-- /#header-toolbar -->
        </header>
         <section id="right-content-wrapper" style="overflow:hidden;" class="mCustomScrollbar" data-mcs-theme="minimal-dark">
          <div class="right-content-outter">
          
            <?php
         switch($page){

          case 'FORM'       : include "formKasir.php";
          break;
		  case 'User'       : include "formUser.php";
          break;
        }
          ?>
          </div>
          <div id="page-footer" class="padding-1">
            <div>
              <strong>FRP</strong> - Web App Framework Copyright © 2016-2017
            </div>
          </div>
        </section><!-- /#right-content-wrapper -->
      </section>

    </div>

    <!-- Core Scripts - Include with every page -->
    <script src="<?=base_url()?>assets/Login/js/jquery-1.9.1.js" type="text/javascript"></script>
    <script src="<?=base_url()?>assets/kasir/jquery-ui.custom.min.js" type="text/javascript"></script>
    <script src="<?=base_url()?>assets/bs3.3.7/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="<?=base_url()?>assets/Login/modernizr.js" type="text/javascript"></script>
    <script src="<?=base_url()?>assets/kasir/LAB.min.js" type="text/javascript"></script>
    <script src="<?=base_url()?>assets/kasir/bemat-admin-common.js" type="text/javascript"></script>
    <script src="<?=base_url()?>assets/malihu-custom-scrollbar-plugin-master/jquery.mCustomScrollbar.concat.min.js"></script>
    <script type="text/javascript" src="<?=base_url()?>assets/datatables/js/dataTables.bootstrap.js"></script>
    <script type="text/javascript" src="<?=base_url()?>assets/datatables/js/jquery.dataTables.min.js"></script>
  </body>
</html>