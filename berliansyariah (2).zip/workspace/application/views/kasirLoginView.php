<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>LOGIN</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="<?=base_url()?>assets/Login/preview.css" rel="stylesheet" />
    <script src="<?=base_url()?>assets/Login/modernizr.js"></script>
    <link rel="stylesheet" href="<?=base_url()?>assets/fontawesome/css/font-awesome.css" />
    <style>
        body {
    background:url('')  no-repeat center center fixed;
            }
        #formLogin{
    background:url('<?=base_url()?>/assets/BlurImage.jpg')  no-repeat center center fixed;
        }
    </style>
 </head>
 <body class="eternity-form" > 
 <h2 align="middle"> Sistem Informasi Guest House Berlian Syariah</h2>
 

    <section class="colorBg6 colorBg dark active" id="formLogin">
        <div class="container">
 
            <div class="login-form-section">
                <div class="login-content " data-animation="bounceIn">
                    <form action="<?=base_url()?>Login" method="post">
                        <div class="section-title">
                            <h3>Silakan Login ke akun anda</h3>
                        </div>
                        <div class="textbox-wrap">
                            <div class="input-group">
                                <span class="input-group-addon "><i class="icon-user icon-color"></i></span>
                                <input type="text" required="required" class="form-control" name="username" placeholder="Username" />
                            </div>
                        </div>
                        <div class="textbox-wrap">
                            <div class="input-group">
                                <span class="input-group-addon "><i class="icon-key icon-color"></i></span>
                                <input type="password" required="required" class="form-control" name="password" placeholder="Password" />
                            </div>
                        </div>
                        <div class="login-form-action clearfix">
                            <button type="submit" class="btn btn-success pull-right green-btn">Login &nbsp; <i class="icon-chevron-right"></i></button>
                        </div>
                    </form>
                </div>
                <div class="login-form-links link1 " data-animation="fadeInRightBig" data-animation-delay=".2s">
                    <h4 class="blue">Belum mempunyai akun?</h4><h4 class="green">atau lupa dengan password?</h4>
                    <span>Hubungi Admin untuk melakukan registrasi atau menanyakan password</span>
                </div>
            </div>
        </div>
    </section>

    <script src="<?=base_url()?>assets/Login/js/jquery-1.9.1.js"></script>
    <script src="<?=base_url()?>assets/bs3.3.7/js/bootstrap.js"></script>
    <script src="<?=base_url()?>assets/Login/js/respond.src.js"></script>
    <script src="<?=base_url()?>assets/Login/js/jquery.icheck.js"></script>
    <script src="<?=base_url()?>assets/Login/js/placeholders.min.js"></script>
    <script src="<?=base_url()?>assets/Login/js/waypoints.min.js"></script>
    <script src="<?=base_url()?>assets/Login/js/jquery.panelSnap.js"></script>

    <script type="text/javascript">
        $(function () {
            $("input").iCheck({
                checkboxClass: 'icheckbox_square-blue',
                increaseArea: '20%' // optional
            });
            $(".dark input").iCheck({
                checkboxClass: 'icheckbox_polaris',
                increaseArea: '20%' // optional
            });
            $(".form-control").focus(function () {
                $(this).closest(".textbox-wrap").addClass("focused");
            }).blur(function () {
                $(this).closest(".textbox-wrap").removeClass("focused");
            });

            //On Scroll Animations


            if ($(window).width() >= 968 && !Modernizr.touch && Modernizr.cssanimations) {

                $("body").addClass("scroll-animations-activated");
                $('[data-animation-delay]').each(function () {
                    var animationDelay = $(this).data("animation-delay");
                    $(this).css({
                        "-webkit-animation-delay": animationDelay,
                        "-moz-animation-delay": animationDelay,
                        "-o-animation-delay": animationDelay,
                        "-ms-animation-delay": animationDelay,
                        "animation-delay": animationDelay
                    });

                });
                $('[data-animation]').waypoint(function (direction) {
                    if (direction == "down") {
                        $(this).addClass("animated " + $(this).data("animation"));

                    }
                }, {
                    offset: '90%'
                }).waypoint(function (direction) {
                    if (direction == "up") {
                        $(this).removeClass("animated " + $(this).data("animation"));

                    }
                }, {
                    offset: $(window).height() + 1
                });
            }

            //End On Scroll Animations


            $(".main-nav a[href]").click(function () {
                var scrollElm = $(this).attr("href");

                $("html,body").animate({ scrollTop: $(scrollElm).offset().top }, 500);

                $(".main-nav a[href]").removeClass("active");
                $(this).addClass("active");
            });




            if ($(window).width() > 1000 && !Modernizr.touch) {
                var options = {
                    $menu: ".main-nav",
                    menuSelector: 'a',
                    panelSelector: 'section',
                    namespace: '.panelSnap',
                    onSnapStart: function () { },
                    onSnapFinish: function ($target) {
                        $target.find('input:first').focus();
                    },
                    directionThreshold: 50,
                    slideSpeed: 200
                };
                $('body').panelSnap(options);

            }

            $(".colorBg a[href]").click(function () {
                var scrollElm = $(this).attr("href");

                $("html,body").animate({ scrollTop: $(scrollElm).offset().top }, 500);

                return false;
            });


           

        });
    </script>

</body>
</html>
