<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {
	function __construct(){ 
        parent::__construct();
		$this->load->helper(array('form','url', 'text_helper','date'));
		$this->load->database();
		$this->load->library(array('Pagination','user_agent','session','form_validation','upload'));
		$this->load->helper("file");
		$this->load->model('User_model');
		@session_start();
		
    }

	public function index()
	{
		$a['page']	= "User";
		$a['dataUser'] = $this->User_model->tampil_user()->result_object();
		$this->load->view('HomeKasir',$a);
	}

	public function create()
	{
		if($this->input->post()){
			$this->form_validation->set_rules('username','Username','required');
			$this->form_validation->set_rules('pass','Password','required');
			$this->form_validation->set_rules('nama','Nama','required');
			$this->form_validation->set_rules('alamat','Alamat','required');
			$this->form_validation->set_rules('tgl_lahir','Tanggal Lahir','required');
			$this->form_validation->set_rules('jk','Jenis Kelamin','required');
			$this->form_validation->set_rules('jabatan','Jabatan','required');
			$this->form_validation->set_rules('noTelp','No Telp','required');
			if ($this->form_validation->run() == TRUE){
				if($_FILES['file_name']['size'] < 9999999){ //$_FILES adalah fungsi php untuk memanggil hasil dari inputan file dengan nama file_name, size adalah menghitung ukuran file
					$config['upload_path'] = './data';
		        	$config['allowed_types'] = 'gif|jpg|png';
		        	$config['max_size']    = '9999999';
					$config['encrypt_name']  = TRUE;
					$config['file_name']  = $this->input->post('file_name');
					$this->upload->initialize($config);
		        	$this->load->library('upload');
		    			if ($_FILES['file_name']['name'] != null) {    	
							if (!$this->upload->do_upload('file_name')){ //jika tidak mengupload 
								$data['error'] = $this->upload->display_errors();
								$data['page']			= "Add User";
					  			$this->load->view('HomeKasir',$data);
				        	}else{ //tapi lek mengupload
								$datas      = $this->upload->data();
									$data = array(
									'username' => $this->input->post('username'),
									'nama' => $this->input->post('nama'),
									'alamat' => $this->input->post('alamat'),
									'tgl_lahir' => $this->input->post('tgl_lahir'),
									'jk' => $this->input->post('jk'),
									'jabatan' => $this->input->post('jabatan'),
									'noTelp' => $this->input->post('noTelp'),
									'password' => md5($this->input->post('pass')),
									'foto' => $datas['file_name'] //mengambil fungsi dari data library upload dengan file_name=mengambil nama file tersebut
									);
								$this->User_model->add_record("user", $data);
								$this->index(); //mengembalikan ke halaman index di controller Buah	
				        	}
		    			}else{
			        			$data = array(
									'username' => $this->input->post('username'),
									'nama' => $this->input->post('nama'),
									'alamat' => $this->input->post('alamat'),
									'tgl_lahir' => $this->input->post('tgl_lahir'),
									'jk' => $this->input->post('jk'),
									'jabatan' => $this->input->post('jabatan'),
									'noTelp' => $this->input->post('noTelp'),
									'password' => md5($this->input->post('pass'))
									);
								$this->User_model->add_record("user", $data);
								$this->index();	
		        			}
				}else{
					$data['page']			= "Add User";
					$data['error']			= "File Gambar Terlalu Besar";
	  				$this->load->view('HomeKasir',$data);						
				}
			}else{
				$data['page']			= "Add User";
				$data['error']			= "Format Masukan Salah, Pastikan data sudah terisi";
	  			$this->load->view('HomeKasir',$data);
			}
		}else{
			$data['page']			= "Add User";
	  		$this->load->view('HomeKasir',$data);
		}
	}

	public function profil(){
		$a['page']="PROFIL";
		$this->load->view('HomeKasir',$a);
	}
	public function example()
	{
		$this->load->view('kasirHomeView');
	}
}
