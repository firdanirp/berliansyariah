<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kasir extends CI_Controller {
function __construct() {
		parent::__construct();
		$this->load->helper(array('form','url', 'text_helper','date'));
		$this->load->database();
		$this->load->library(array('Pagination','user_agent','session','form_validation','upload'));
		
			@session_start();
	}
	public function index()
	{
		$a['page']	= "FORM";
		$this->load->view('HomeKasir',$a);
	}

	public function order()
	{
		$this->load->view('kasirOrderView');
	}

	public function profil(){
		$a['page']="PROFIL";
		$this->load->view('homeKasir',$a);
	}
	public function example()
	{
		$this->load->view('kasirHomeView');
	}
}
