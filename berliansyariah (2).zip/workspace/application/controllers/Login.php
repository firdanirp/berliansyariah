<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {

	function __construct() {
		parent::__construct();
		$this->load->helper(array('form','url', 'text_helper','date'));
		$this->load->database();
		$this->load->library(array('Pagination','user_agent','session','form_validation','upload'));
		$this->load->model('Login_model');
		$this->load->model('User_model');
			@session_start();
	}
	
	public function index()
	{	
		if ($this->input->post()) {
		$username = strtolower($this->input->post("username")); 
		$passworda = strtolower($this->input->post("password")); 
		$pass = md5($passworda); 
			if($username == "" || $this->input->post('password') == ""){ 
				$data['error'] = "Username atau Password Tidak Boleh Kosong"; 
				$this->load->view('kasirLoginView',$data);  
			}else{
				$this->form_validation->set_rules('username','Username','required|strtolower');
			    $this->form_validation->set_rules('password','Password','required|strtolower'); 
			
					if ($this->form_validation->run() == TRUE){
						$query = $this->db->query("SELECT * FROM user WHERE username = '".$username."' AND password = '".$pass."'");
					
						if($query->num_rows()>=1){
							foreach ($query->result() as $row)
							{
								$user1 	  = $row->idUser; 
								$username = $row->username;
								$nama 	  = $row->nama;
								$foto	  = $row->foto;
								$jabatan  = $row->jabatan;
							}
					
							$data = array(
								   'idUser'    => $user1, 
								   'username'  => $username,
								   'foto'	   => $foto,
								   'nama'	   => $nama,
								   'jabatan'   => $jabatan
							   );
							$this->session->set_userdata($data,true); 
							$data['page'] = "content";
							$this->load->view('HomeKasir',$data); 
						}
						else // incorrect username or password
						{
							$data['error'] = "Username atau Password Salah, Data Tidak Ditemukan";
							$this->load->view('kasirLoginView',$data);	
						}
					}
					else
					{
						$data['error'] = "Format Masukan Salah, Periksa dan Coba Lagi";
						$this->load->view('kasirLoginView',$data);
					}
					
			
			}
	}else{
		
	  	$this->load->view('kasirLoginView');	
	}
		
	}
	
	
    function logout()
	{
			$data = array(
                   'id_user'  => ''
            	   );
			$this->session->set_userdata($data,false);
			redirect(base_url());
	}
	
}
?>