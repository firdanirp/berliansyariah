<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'Login';
$route['Kasir']              = 'Kasir';
$route['User']              = 'User';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
